﻿using System;
using HospiEnCasa.App.Dominio;

namespace HospiEnCasa.App.Consola
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World Entity Framework!");
        }
    }
}

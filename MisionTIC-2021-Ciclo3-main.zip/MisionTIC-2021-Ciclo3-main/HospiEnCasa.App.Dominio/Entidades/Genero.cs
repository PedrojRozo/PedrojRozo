namespace HospiEnCasa.App.Dominio
{
    /// <summary>
    /// Lista de generos
    /// </summary>
    public enum Genero
    {
        Masculino,
        Femenino,
        Bisexual,
        Intersexual,
        Pansexual,
        Transexual

    }
}